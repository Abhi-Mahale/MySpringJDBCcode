CREATE table Employee(
 id int auto_increment,
 first_name varchar(30),
 last_name varchar(30),
 email varchar(50),
 primary key(id)
);

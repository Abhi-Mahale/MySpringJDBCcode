package com.jdbc.Spring.boot.using.JDBC.Controller;

import com.jdbc.Spring.boot.using.JDBC.Model.Employee;
import com.jdbc.Spring.boot.using.JDBC.dao.EmployeeDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
public class EmployeeController {

    private final EmployeeDao employeeDao;

    @Autowired
    public EmployeeController(EmployeeDao employeeDao) {
        this.employeeDao = employeeDao;
    }

    @PostMapping("/add")
    public void addEmployee(@Valid @RequestBody Employee employee)
    {
        employeeDao.addEmployee(employee);
    }

    @GetMapping("/all")
    public List<Employee> findAll()
    {
        return  employeeDao.findAll();
    }

    @GetMapping("/employee/{id}")
    public Optional<Employee> findById(@Valid @RequestBody Employee employee, @PathVariable("id") int id)
    {
        return employeeDao.findById(id);
    }

    @PutMapping("/update/{id}")
     public int updateEmployee(@Valid @RequestBody Employee employee, @PathVariable("id") int id)
    {
        return employeeDao.updateEmployee(id,employee);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteEmployee(@PathVariable int id)
    {
        employeeDao.deleteEmployee(id);
    }

}
